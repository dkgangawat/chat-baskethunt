Steps:-


"npm i"
"npm run server"